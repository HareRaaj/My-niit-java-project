package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import model.Student2;
import utility.DBConn;

public class RegisterDAO 
{
	Connection conn;
	public RegisterDAO()throws Exception
	{
		conn=DBConn.getMySQLConnection();
	}
	
	public boolean registerStudent(Student2 student)throws SQLException
	{
		PreparedStatement psmt=conn.prepareStatement("insert into student2 value(?,?,?,?,?,?,?,?)");
		
		psmt.setString(1, student.getUsername());
		psmt.setString(2, student.getPassword2());
		psmt.setString(3, student.getstudentName());
		psmt.setString(4, student.getGender());
		psmt.setString(5, student.getEmailid());
		psmt.setString(6, student.getMobileno());
		psmt.setString(7, student.getCollegeName());
		psmt.setString(8, student.getCourseName());
		
		int row_eff=psmt.executeUpdate();
		
		if(row_eff>0)
			return true;
		else
			return false;

	}
	
	public Student2 checkCredential(Student2 student)throws SQLException
	{
		PreparedStatement psmt=conn.prepareStatement("select*from Student2 where username=? and password2=?");
		
		psmt.setString(1, student.getUsername());
		psmt.setString(2, student.getPassword2());
		
		ResultSet rs=psmt.executeQuery();
		
		if(rs.next())
		{
			student.setstudentName(rs.getString(3));
		}
		else
		{
			student=null;
		}
		return student;
	}
}
