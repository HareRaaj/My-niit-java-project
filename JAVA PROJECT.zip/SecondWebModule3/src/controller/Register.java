package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.RegisterDAO;
import model.Student2;


@WebServlet("/Register")
public class Register extends HttpServlet
{
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		try
		{
			String username=request.getParameter("username");
			String password2=request.getParameter("passwd");
			String studentName=request.getParameter("studentName");
			String gender=request.getParameter("gender");
			String mobileNo=request.getParameter("mobileNo");
			String emailid=request.getParameter("emailid");
			String collegeName=request.getParameter("collegename");
			String courseName=request.getParameter("courseName");
			
		
			out.println("User Name:"+username);
			out.println("Password:"+password2);
			out.println("Student Name:"+studentName);
			out.println("Gender:"+gender);
			out.println("Mobile NO:"+mobileNo);
			out.println("emailid:"+emailid);
			out.println("College Name:"+collegeName);
			out.println("Course Name:"+courseName);
			
			Student2 student=new Student2(username,password2,studentName,gender,mobileNo,emailid,collegeName,courseName);
		
			RegisterDAO registerDAO=new RegisterDAO();
		
			if(registerDAO.registerStudent(student))
			{
				request.setAttribute("username", student.getUsername());
				RequestDispatcher dispatch=request.getRequestDispatcher("UserHome.jsp");
				dispatch.forward(request, response);
			}
			else
			{
				request.setAttribute("errorInfo", "Error occured during Registering");
				RequestDispatcher dispatch=request.getRequestDispatcher("ErrorPage.jsp");
				dispatch.forward(request, response);
			}
			}
			catch(Exception e)
			{
				request.setAttribute("errorInfo", "Error occured during Registering::::"+e.getMessage());
				RequestDispatcher dispatch=request.getRequestDispatcher("ErrorPage.jsp");
				dispatch.forward(request, response);
			}
	}

}
