package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.RegisterDAO;
import model.Student2;


@WebServlet("/LoginCheck")
public class LoginCheck extends HttpServlet
{
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		try
		{
		String username=request.getParameter("username");
		String password2=request.getParameter("passwd");
		
		Student2 student=new Student2();
		student.setUsername(username);
		student.setPassword2(password2);
		
		RegisterDAO registerDAO=new RegisterDAO();
		Student2 student1=registerDAO.checkCredential(student);
		
		if(student1!=null)
		{
			request.setAttribute("username", student.getUsername());
			RequestDispatcher dispatch=request.getRequestDispatcher("UserHome.jsp");
			dispatch.forward(request, response);
		}
		else
		{
			request.setAttribute("errorInfo", "Error occured during Logging");
			RequestDispatcher dispatch=request.getRequestDispatcher("ErrorPage.jsp");
			dispatch.forward(request, response);
		}
		}
		catch(Exception e)
		{
			request.setAttribute("errorInfo", "Error occured during Logging::::"+e.getMessage());
			RequestDispatcher dispatch=request.getRequestDispatcher("ErrorPage.jsp");
			dispatch.forward(request, response);
		}
	}
}


