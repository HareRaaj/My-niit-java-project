package model;

public class Student2 
{
	String username;
	String password2;
	String studentName;
	String gender;
	String emailid;
	String mobileno;
	String collegeName;
	String courseName;
	
	public Student2() {}
	
	public Student2(String username, String password2, String studentName, String gender, String emailid, String mobileno, String collegeName, String courseName)
	{
		this.username=username;
		this.password2=password2;
		this.studentName=studentName;
		this.gender=gender;
		this.emailid=emailid;
		this.mobileno=mobileno;
		this.collegeName=collegeName;
		this.courseName=courseName;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword2() {
		return password2;
	}

	public void setPassword2(String password2) {
		this.password2 = password2;
	}

	public String getstudentName() {
		return studentName;
	}

	public void setstudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getEmailid() {
		return emailid;
	}

	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}

	public String getMobileno() {
		return mobileno;
	}

	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}

	public String getCollegeName() {
		return collegeName;
	}

	public void setCollegeName(String collegeName) {
		this.collegeName = collegeName;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	
}
